﻿-- Drop tables if they already exist (optional)
DROP TABLE IF EXISTS Repayments;
DROP TABLE IF EXISTS Loans;
DROP TABLE IF EXISTS Expenses;
DROP TABLE IF EXISTS Income;

-- Create Income table
CREATE TABLE Income (
    income_id INT PRIMARY KEY,
    source VARCHAR(50),
    amount DECIMAL(10, 2),
    received_date DATE
);

-- Create Expenses table
CREATE TABLE Expenses (
    expense_id INT PRIMARY KEY,
    category VARCHAR(50),
    amount DECIMAL(10, 2),
    expense_date DATE
);

-- Create Loans table
CREATE TABLE Loans (
    loan_id INT PRIMARY KEY,
    lender_name VARCHAR(50),
    amount DECIMAL(10, 2),
    loan_date DATE,
    due_date DATE
);

-- Create Repayments table
CREATE TABLE Repayments (
    repayment_id INT PRIMARY KEY,
    loan_id INT FOREIGN KEY REFERENCES Loans(loan_id),
    amount DECIMAL(10, 2),
    repay_date DATE
);

-- Insert into Income
INSERT INTO Income (income_id, source, amount, received_date) VALUES
(1, 'Parents', 5000.00, '2025-01-05'),
(2, 'Scholarship', 2000.00, '2025-01-15'),
(3, 'Part-time Job', 3000.00, '2025-02-01'),
(4, 'Parents', 5000.00, '2025-02-05'),
(5, 'Scholarship', 2000.00, '2025-02-15'),
(6, 'Parents', 5000.00, '2025-03-05'),
(7, 'Part-time Job', 3200.00, '2025-03-10'),
(8, 'Parents', 5000.00, '2025-04-05'),
(9, 'Scholarship', 2500.00, '2025-04-18'),
(10, 'Parents', 5000.00, '2025-05-05');

-- Insert into Expenses
INSERT INTO Expenses (expense_id, category, amount, expense_date) VALUES
(1, 'Food', 1500.00, '2025-01-06'),
(2, 'Books', 1200.00, '2025-01-10'),
(3, 'Recharge', 300.00, '2025-01-20'),
(4, 'Entertainment', 800.00, '2025-02-03'),
(5, 'Stationery', 400.00, '2025-02-11'),
(6, 'Travel', 600.00, '2025-02-21'),
(7, 'Food', 1800.00, '2025-03-05'),
(8, 'Medical', 900.00, '2025-03-20'),
(9, 'Books', 1000.00, '2025-04-15'),
(10, 'Entertainment', 1200.00, '2025-05-01');

-- Insert into Loans
INSERT INTO Loans (loan_id, lender_name, amount, loan_date, due_date) VALUES
(1, 'Arjun', 2000.00, '2025-01-12', '2025-02-28'),
(2, 'Swiggy Loan', 1500.00, '2025-01-25', '2025-03-01'),
(3, 'Ravi', 2500.00, '2025-02-10', '2025-03-15'),
(4, 'PayLater App', 1000.00, '2025-02-25', '2025-04-01'),
(5, 'Meena', 1800.00, '2025-03-05', '2025-04-30'),
(6, 'Kumar', 2200.00, '2025-03-15', '2025-05-01'),
(7, 'MobiLoan', 3000.00, '2025-04-01', '2025-06-01'),
(8, 'Deepak', 900.00, '2025-04-12', '2025-05-15'),
(9, 'Bharat', 1100.00, '2025-05-02', '2025-06-10'),
(10, 'FlexiPay', 1200.00, '2025-05-10', '2025-06-20');

-- Insert into Repayments
INSERT INTO Repayments (repayment_id, loan_id, amount, repay_date) VALUES
(1, 1, 500.00, '2025-01-20'),
(2, 1, 1000.00, '2025-02-10'),
(3, 2, 1500.00, '2025-02-28'),
(4, 3, 1000.00, '2025-03-01'),
(5, 3, 500.00, '2025-03-20'),
(6, 4, 1000.00, '2025-03-25'),
(7, 5, 800.00, '2025-04-10'),
(8, 5, 500.00, '2025-04-28'),
(9, 6, 1200.00, '2025-05-05'),
(10, 7, 1500.00, '2025-05-15');



-- ========================================
-- 🔹 1. Monthly Income Summary
-- ========================================
SELECT 
    FORMAT(received_date, 'yyyy-MM') AS month,
    SUM(amount) AS total_income
FROM Income
GROUP BY FORMAT(received_date, 'yyyy-MM')
ORDER BY month;

-- ========================================
-- 🔹 2. Monthly Expense Summary
-- ========================================
SELECT 
    FORMAT(expense_date, 'yyyy-MM') AS month,
    SUM(amount) AS total_expense
FROM Expenses
GROUP BY FORMAT(expense_date, 'yyyy-MM')
ORDER BY month;

-- ========================================
-- 🔹 3. Net Monthly Savings (Income - Expense)
-- ========================================
WITH monthly_income AS (
    SELECT FORMAT(received_date, 'yyyy-MM') AS month, SUM(amount) AS income
    FROM Income
    GROUP BY FORMAT(received_date, 'yyyy-MM')
),
monthly_expense AS (
    SELECT FORMAT(expense_date, 'yyyy-MM') AS month, SUM(amount) AS expense
    FROM Expenses
    GROUP BY FORMAT(expense_date, 'yyyy-MM')
)
SELECT 
    COALESCE(i.month, e.month) AS month,
    ISNULL(i.income, 0) AS total_income,
    ISNULL(e.expense, 0) AS total_expense,
    ISNULL(i.income, 0) - ISNULL(e.expense, 0) AS net_savings
FROM monthly_income i
FULL OUTER JOIN monthly_expense e ON i.month = e.month
ORDER BY month;

-- ========================================
-- 🔹 4. Total Spending by Category
-- ========================================
SELECT 
    category,
    SUM(amount) AS total_spent
FROM Expenses
GROUP BY category
ORDER BY total_spent DESC;

-- ========================================
-- 🔹 5. Highest Single Expense
-- ========================================
SELECT TOP 1 *
FROM Expenses
ORDER BY amount DESC;

-- ========================================
-- 🔹 6. Loan Summary: Borrowed, Repaid, Balance
-- ========================================
SELECT 
    l.loan_id,
    l.lender_name,
    l.amount AS loan_amount,
    ISNULL(SUM(r.amount), 0) AS repaid_amount,
    l.amount - ISNULL(SUM(r.amount), 0) AS balance_amount
FROM Loans l
LEFT JOIN Repayments r ON l.loan_id = r.loan_id
GROUP BY l.loan_id, l.lender_name, l.amount;

-- ========================================
-- 🔹 7. Loans Fully Repaid
-- ========================================
SELECT l.loan_id, l.lender_name, l.amount
FROM Loans l
LEFT JOIN (
    SELECT loan_id, SUM(amount) AS repaid
    FROM Repayments
    GROUP BY loan_id
) r ON l.loan_id = r.loan_id
WHERE ISNULL(r.repaid, 0) >= l.amount;

-- ========================================
-- 🔹 8. Upcoming Loan Due Dates (Next 15 Days)
-- ========================================
SELECT *
FROM Loans
WHERE due_date BETWEEN GETDATE() AND DATEADD(DAY, 15, GETDATE());







-- View: Monthly Income Summary
CREATE VIEW v_MonthlyIncome AS
SELECT 
    FORMAT(received_date, 'yyyy-MM') AS month,
    SUM(amount) AS total_income
FROM Income
GROUP BY FORMAT(received_date, 'yyyy-MM');

-- View: Monthly Expense Summary
CREATE VIEW v_MonthlyExpense AS
SELECT 
    FORMAT(expense_date, 'yyyy-MM') AS month,
    SUM(amount) AS total_expense
FROM Expenses
GROUP BY FORMAT(expense_date, 'yyyy-MM');

-- View: Net Monthly Savings
CREATE VIEW v_NetMonthlySavings AS
WITH monthly_income AS (
    SELECT FORMAT(received_date, 'yyyy-MM') AS month, SUM(amount) AS income
    FROM Income
    GROUP BY FORMAT(received_date, 'yyyy-MM')
),
monthly_expense AS (
    SELECT FORMAT(expense_date, 'yyyy-MM') AS month, SUM(amount) AS expense
    FROM Expenses
    GROUP BY FORMAT(expense_date, 'yyyy-MM')
)
SELECT 
    COALESCE(i.month, e.month) AS month,
    ISNULL(i.income, 0) AS total_income,
    ISNULL(e.expense, 0) AS total_expense,
    ISNULL(i.income, 0) - ISNULL(e.expense, 0) AS net_savings
FROM monthly_income i
FULL OUTER JOIN monthly_expense e ON i.month = e.month;



-- Procedure: Get loan summary by lender name
CREATE PROCEDURE sp_GetLoanSummaryByLender
    @LenderName VARCHAR(50)
AS
BEGIN
    SELECT 
        l.loan_id,
        l.lender_name,
        l.amount AS loan_amount,
        ISNULL(SUM(r.amount), 0) AS repaid_amount,
        l.amount - ISNULL(SUM(r.amount), 0) AS balance_amount
    FROM Loans l
    LEFT JOIN Repayments r ON l.loan_id = r.loan_id
    WHERE l.lender_name = @LenderName
    GROUP BY l.loan_id, l.lender_name, l.amount;
END;
EXEC sp_GetLoanSummaryByLender 'Arjun';





-- Running total of expenses by category over time
SELECT 
    category,
    expense_date,
    amount,
    SUM(amount) OVER (PARTITION BY category ORDER BY expense_date) AS running_total
FROM Expenses;

-- Rank months by net savings (Highest to Lowest)
SELECT 
    month,
    total_income,
    total_expense,
    net_savings,
    RANK() OVER (ORDER BY net_savings DESC) AS savings_rank
FROM v_NetMonthlySavings;


