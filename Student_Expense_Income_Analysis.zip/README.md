# 📊 Student Expense & Income Analysis

This project aims to analyze a student's financial behavior through tracking income, expenses, loans, and repayments using **SQL** and **Power BI**.

---

## 🔧 Tools & Technologies Used

- **Microsoft SQL Server** – Data storage, queries, procedures
- **Power BI** – Dashboard visualizations and data analysis
- **DAX** – Measures and calculated columns

---

## 📁 Project Structure

- **SQL_Scripts/** – Contains all SQL files
  - Table creation
  - Data insertion
  - Analytical queries
  - Views & stored procedures
- **.pbix file** – Power BI dashboard
- **Screenshots/** – Dashboard preview
- **README.md** – Project overview

---

## 📊 Dashboard Insights

- Monthly trends for income, expenses, and loans
- Source-wise income (Parents, Job, Scholarship)
- Category-wise expenses (Food, Books, etc.)
- Loan tracking with repayment overview

---

## 🧠 Skills Demonstrated

- Writing SQL queries with JOINs, aggregations
- Using Views and Stored Procedures
- Creating visual dashboards using Power BI
- Analyzing financial behavior via charts and metrics

---

## 🚀 How to Run

1. Run SQL scripts in your SQL Server Management Studio.
2. Open `.pbix` file in Power BI Desktop.
3. Connect to your SQL database (or use the embedded dataset).
4. Refresh visuals.

---

## 👤 Author

**Gangalakshmi Raja**

For academic/demo purposes only.
